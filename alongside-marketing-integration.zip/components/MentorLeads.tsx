"use client";
// components/MentorLeads.tsx
// Admin view of captured + auto-qualified mentor leads. Protect the route with auth.

import React, { useEffect, useState } from "react";
import { Loader2, RefreshCw, Mail, Clock } from "lucide-react";

const BRAND = "#0E7C7B";

interface Lead {
  id: number; name: string; email: string; lifeEvent: string; story: string;
  availability: string; score: number; status: string; qualificationNotes: string;
  createdAt: string; updatedAt: string;
}

const STATUS_COLORS: Record<string, string> = {
  qualified: "#15803d", not_ready: "#b45309", new: "#64748b", contacted: "#1971c2", converted: "#0E7C7B",
};
const FILTERS = ["all", "qualified", "not_ready", "contacted", "converted"] as const;

export default function MentorLeads() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("all");

  async function load() {
    setLoading(true);
    try {
      const q = filter === "all" ? "" : `?status=${filter}`;
      const res = await fetch(`/api/mentor-leads${q}`);
      const data = await res.json();
      setLeads(data.leads ?? []);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { void load(); /* eslint-disable-next-line */ }, [filter]);

  async function setStatus(id: number, status: string, score: number, notes: string) {
    await fetch("/api/mentor-leads", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status, score, notes }),
    });
    void load();
  }

  return (
    <div className="ml-wrap">
      <div className="ml-head">
        <div>
          <div className="ml-eyebrow">MyAlongside</div>
          <h1>Mentor Leads</h1>
        </div>
        <div style={{ display: "flex" }}>
          <button className="ml-refresh" onClick={load}><RefreshCw size={14} /> Refresh</button>
          <button className="ml-refresh" onClick={async () => { await fetch("/api/admin/logout", { method: "POST" }); window.location.href = "/marketing/login"; }} style={{ marginLeft: 8 }}>Sign out</button>
        </div>
      </div>

      <div className="ml-filters">
        {FILTERS.map((f) => (
          <button key={f} className={filter === f ? "on" : ""} onClick={() => setFilter(f)}>
            {f.replace("_", " ")}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="ml-loading"><Loader2 className="spin" size={18} /> Loading…</div>
      ) : leads.length === 0 ? (
        <p className="ml-empty">No leads in this view yet.</p>
      ) : (
        <div className="ml-list">
          {leads.map((l) => (
            <div key={l.id} className="ml-card">
              <div className="ml-card-top">
                <div>
                  <div className="ml-name">{l.name}</div>
                  <a className="ml-email" href={`mailto:${l.email}`}><Mail size={12} /> {l.email}</a>
                </div>
                <div className="ml-score" style={{ color: l.score >= 60 ? "#15803d" : "#b45309" }}>{l.score}<span>/100</span></div>
              </div>
              <div className="ml-meta">
                <span className="ml-badge" style={{ color: STATUS_COLORS[l.status] ?? "#555", borderColor: (STATUS_COLORS[l.status] ?? "#999") + "55" }}>{l.status.replace("_", " ")}</span>
                <span className="ml-event">{l.lifeEvent}</span>
                {l.availability && <span className="ml-avail"><Clock size={11} /> {l.availability}</span>}
              </div>
              <p className="ml-story">{l.story}</p>
              {l.qualificationNotes && <p className="ml-notes"><b>AI assessment:</b> {l.qualificationNotes}</p>}
              <div className="ml-actions">
                <button onClick={() => setStatus(l.id, "contacted", l.score, l.qualificationNotes)}>Mark contacted</button>
                <button onClick={() => setStatus(l.id, "converted", l.score, l.qualificationNotes)}>Mark converted</button>
                <button className="ghost" onClick={() => setStatus(l.id, "qualified", Math.max(l.score, 60), l.qualificationNotes)}>Override → qualified</button>
              </div>
            </div>
          ))}
        </div>
      )}

      <style jsx>{`
        .ml-wrap { font-family: 'Inter', system-ui, sans-serif; max-width: 860px; margin: 0 auto; padding: 26px 18px; color: #1a1a1a; }
        .ml-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
        .ml-eyebrow { font-size: 11.5px; letter-spacing: .5px; text-transform: uppercase; color: ${BRAND}; font-weight: 700; }
        .ml-head h1 { font-size: 24px; font-weight: 800; margin: 2px 0 0; }
        .ml-refresh { display: flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 600; color: ${BRAND}; background: #fff; border: 1.5px solid ${BRAND}; border-radius: 9px; padding: 8px 13px; cursor: pointer; }
        .ml-filters { display: flex; gap: 6px; margin-bottom: 18px; flex-wrap: wrap; }
        .ml-filters button { font-size: 12.5px; font-weight: 600; text-transform: capitalize; color: #567; background: #eef4f4; border: none; border-radius: 8px; padding: 7px 12px; cursor: pointer; }
        .ml-filters button.on { background: ${BRAND}; color: #fff; }
        .ml-loading, .ml-empty { color: #999; font-size: 14px; display: flex; align-items: center; gap: 8px; }
        .ml-list { display: flex; flex-direction: column; gap: 12px; }
        .ml-card { background: #fff; border: 1px solid #ececec; border-radius: 13px; padding: 15px 16px; box-shadow: 0 1px 6px rgba(0,0,0,.03); }
        .ml-card-top { display: flex; justify-content: space-between; align-items: flex-start; }
        .ml-name { font-weight: 700; font-size: 15.5px; }
        .ml-email { display: inline-flex; align-items: center; gap: 4px; font-size: 12.5px; color: #789; text-decoration: none; margin-top: 2px; }
        .ml-score { font-size: 22px; font-weight: 800; }
        .ml-score span { font-size: 12px; font-weight: 600; color: #aaa; }
        .ml-meta { display: flex; align-items: center; gap: 8px; margin: 10px 0; flex-wrap: wrap; }
        .ml-badge { font-size: 11.5px; font-weight: 700; text-transform: capitalize; border: 1.5px solid; border-radius: 6px; padding: 3px 8px; }
        .ml-event { font-size: 12.5px; color: #555; }
        .ml-avail { display: inline-flex; align-items: center; gap: 4px; font-size: 12px; color: #789; }
        .ml-story { font-size: 13.5px; line-height: 1.5; color: #333; margin: 6px 0; }
        .ml-notes { font-size: 12.5px; line-height: 1.5; color: #567; background: #f7faf9; border-radius: 8px; padding: 8px 10px; margin: 8px 0 10px; }
        .ml-actions { display: flex; gap: 8px; flex-wrap: wrap; }
        .ml-actions button { font-size: 12.5px; font-weight: 600; color: #fff; background: ${BRAND}; border: none; border-radius: 8px; padding: 7px 12px; cursor: pointer; }
        .ml-actions button.ghost { color: ${BRAND}; background: #fff; border: 1.5px solid ${BRAND}; }
        .spin { animation: spin 1s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
