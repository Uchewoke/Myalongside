"use client";
// components/BecomeMentorForm.tsx
// Public "Become a Mentor" capture form. Submits to /api/mentor-leads, which
// persists the lead and auto-qualifies it. Embed anywhere (e.g. /signup?role=mentor).

import React, { useState } from "react";
import { Loader2, Heart, CheckCircle2 } from "lucide-react";
import { submitMentorLead } from "@/lib/client";
import Turnstile from "@/components/Turnstile";

const CAPTCHA_ON = !!process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY;

const BRAND = "#0E7C7B";

const LIFE_EVENTS = [
  "Divorce & Separation", "Job Loss & Career", "Grief & Bereavement", "Health Crisis",
  "New Parenthood", "Mental Health", "Addiction & Recovery", "Relocation & Moving",
  "Financial Crisis", "Empty Nest", "Relationship Breakup", "Fresh Start",
];

export default function BecomeMentorForm() {
  const [form, setForm] = useState({ name: "", email: "", lifeEvent: LIFE_EVENTS[0], story: "", availability: "" });
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState<null | { qualified: boolean; notes: string }>(null);
  const [error, setError] = useState("");
  const [captchaToken, setCaptchaToken] = useState("");

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit() {
    setError("");
    if (!form.name || !form.email || !form.story) { setError("Please fill in your name, email, and a little of your story."); return; }
    if (CAPTCHA_ON && !captchaToken) { setError("Please complete the verification below."); return; }
    setLoading(true);
    try {
      const res = await submitMentorLead({ ...form, turnstileToken: captchaToken || undefined });
      setDone({ qualified: res.qualification.status === "qualified", notes: res.qualification.notes });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  if (done) {
    return (
      <div className="bm-wrap">
        <div className="bm-done">
          <CheckCircle2 size={40} color={BRAND} />
          <h2>Thank you for stepping forward.</h2>
          <p>
            {done.qualified
              ? "Your experience could be a lifeline for someone walking the road you've already traveled. Our team will reach out shortly with next steps."
              : "We've received your details and someone from our team will personally follow up. Everyone's story matters here — thank you for offering yours."}
          </p>
          <p className="bm-safety">MyAlongside is peer support, not professional care. If you're in crisis, call 988 (US) or your local emergency services.</p>
        </div>
        <style jsx>{styles}</style>
      </div>
    );
  }

  return (
    <div className="bm-wrap">
      <div className="bm-head"><Heart size={16} color={BRAND} /><span>Become a Mentor</span></div>
      <h2>Turn your hardest chapter into someone's lifeline.</h2>
      <p className="bm-sub">You don't need credentials — just lived experience and the willingness to walk beside someone. Tell us a little about you.</p>

      <label>Your name<input value={form.name} onChange={set("name")} placeholder="First and last name" /></label>
      <label>Email<input type="email" value={form.email} onChange={set("email")} placeholder="you@email.com" /></label>
      <label>What have you come through?
        <select value={form.lifeEvent} onChange={set("lifeEvent")}>
          {LIFE_EVENTS.map((e) => <option key={e} value={e}>{e}</option>)}
        </select>
      </label>
      <label>Your story
        <textarea value={form.story} onChange={set("story")} rows={4} placeholder="In a few sentences — what did you go through, and where are you now? There's no wrong answer." />
      </label>
      <label>Availability (optional)<input value={form.availability} onChange={set("availability")} placeholder="e.g. a couple of hours a week" /></label>

      {error && <div className="bm-error">{error}</div>}

      <Turnstile onVerify={setCaptchaToken} onExpire={() => setCaptchaToken("")} />

      <button className="bm-submit" onClick={submit} disabled={loading || (CAPTCHA_ON && !captchaToken)}>
        {loading ? <><Loader2 className="spin" size={16} /> Sending…</> : "Offer to Mentor"}
      </button>
      <p className="bm-safety">Safe & confidential. We'll never share your story without your permission.</p>

      <style jsx>{styles}</style>
    </div>
  );
}

const styles = `
  .bm-wrap { font-family: 'Inter', system-ui, sans-serif; max-width: 480px; margin: 0 auto; padding: 26px 20px; color: #1a1a1a; }
  .bm-head { display: flex; align-items: center; gap: 8px; }
  .bm-head span { font-size: 12px; letter-spacing: .5px; text-transform: uppercase; color: ${BRAND}; font-weight: 700; }
  h2 { font-size: 23px; font-weight: 800; letter-spacing: -0.5px; margin: 6px 0 6px; line-height: 1.2; }
  .bm-sub { font-size: 14px; color: #667; line-height: 1.55; margin: 0 0 18px; }
  label { display: block; font-size: 13px; font-weight: 600; color: #445; margin-bottom: 14px; }
  input, select, textarea { display: block; width: 100%; margin-top: 6px; border: 1px solid #dde3e3; border-radius: 10px; padding: 11px 13px; font-size: 14px; font-family: inherit; outline: none; box-sizing: border-box; }
  input:focus, select:focus, textarea:focus { border-color: ${BRAND}; }
  textarea { resize: vertical; }
  .bm-error { font-size: 13px; color: #b91c1c; background: #fef2f2; border: 1px solid #fecaca; border-radius: 9px; padding: 9px 12px; margin-bottom: 12px; }
  .bm-submit { width: 100%; font-size: 15px; font-weight: 700; color: #fff; background: ${BRAND}; border: none; border-radius: 11px; padding: 13px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; }
  .bm-submit:disabled { opacity: .7; cursor: default; }
  .bm-safety { font-size: 11.5px; color: #99a; text-align: center; margin-top: 12px; line-height: 1.5; }
  .bm-done { text-align: center; padding: 20px 0; }
  .bm-done h2 { margin-top: 14px; }
  .bm-done p { font-size: 14.5px; color: #556; line-height: 1.6; }
  .spin { animation: spin 1s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
`;
