// app/marketing/leads/page.tsx — admin dashboard for mentor leads. Protect with auth.
import MentorLeads from "@/components/MentorLeads";

export const metadata = { title: "Mentor Leads | MyAlongside" };

export default function LeadsPage() {
  return <MentorLeads />;
}
