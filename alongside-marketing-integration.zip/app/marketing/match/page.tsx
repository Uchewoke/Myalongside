// app/marketing/match/page.tsx — mentor↔mentee matching tool. Protected by middleware.
import MatchFinder from "@/components/MatchFinder";

export const metadata = { title: "Mentor Matching | MyAlongside" };

export default function MatchPage() {
  return <MatchFinder />;
}
