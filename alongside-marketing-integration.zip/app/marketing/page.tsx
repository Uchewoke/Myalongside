// app/marketing/page.tsx
// Mounts the AI marketing team at /marketing
import MarketingTeam from "@/components/MarketingTeam";

export const metadata = {
  title: "AI Marketing Team | MyAlongside",
  description: "12 AI marketing employees driving mentor recruitment and mentee acquisition for MyAlongside.",
};

export default function MarketingPage() {
  return <MarketingTeam />;
}
