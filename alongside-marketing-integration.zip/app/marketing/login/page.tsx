"use client";
// app/marketing/login/page.tsx — reviewer sign-in for the mentor-leads dashboard.

import React, { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Loader2, Lock } from "lucide-react";

const BRAND = "#0E7C7B";

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") || "/marketing/leads";
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function submit() {
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Sign-in failed.");
      router.push(next);
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Sign-in failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="lg-wrap">
      <div className="lg-card">
        <div className="lg-icon"><Lock size={20} color={BRAND} /></div>
        <h1>Reviewer sign-in</h1>
        <p>Access to mentor leads is restricted. Enter the reviewer password.</p>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") submit(); }}
          placeholder="Password"
          autoFocus
        />
        {error && <div className="lg-error">{error}</div>}
        <button onClick={submit} disabled={loading || !password}>
          {loading ? <><Loader2 className="spin" size={16} /> Signing in…</> : "Sign in"}
        </button>
      </div>
      <style jsx>{`
        .lg-wrap { font-family: 'Inter', system-ui, sans-serif; min-height: 70vh; display: flex; align-items: center; justify-content: center; padding: 24px; }
        .lg-card { width: 100%; max-width: 360px; background: #fff; border: 1px solid #ececec; border-radius: 16px; padding: 28px 24px; box-shadow: 0 2px 14px rgba(0,0,0,.05); text-align: center; }
        .lg-icon { width: 44px; height: 44px; border-radius: 12px; background: ${BRAND}18; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px; }
        h1 { font-size: 20px; font-weight: 800; margin: 0 0 6px; }
        p { font-size: 13.5px; color: #667; line-height: 1.5; margin: 0 0 18px; }
        input { width: 100%; border: 1px solid #dde3e3; border-radius: 10px; padding: 11px 13px; font-size: 14px; font-family: inherit; outline: none; box-sizing: border-box; }
        input:focus { border-color: ${BRAND}; }
        .lg-error { font-size: 13px; color: #b91c1c; background: #fef2f2; border: 1px solid #fecaca; border-radius: 9px; padding: 8px 11px; margin-top: 12px; }
        button { width: 100%; margin-top: 14px; font-size: 15px; font-weight: 700; color: #fff; background: ${BRAND}; border: none; border-radius: 11px; padding: 12px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; }
        button:disabled { opacity: .6; cursor: default; }
        .spin { animation: spin 1s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  );
}
