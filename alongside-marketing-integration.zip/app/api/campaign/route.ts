// app/api/campaign/route.ts
// POST { track: "mentor" | "mentee" } -> SSE stream of the chained campaign.
// Each agent runs in sequence and receives the accumulated team output so far,
// so each recruitment track reads as one coordinated campaign.

import { NextRequest } from "next/server";
import { AGENTS, CAMPAIGN_TRACKS, CampaignTrack, systemFor } from "@/lib/agents";
import { runAgent } from "@/lib/anthropic";

export const runtime = "nodejs";
export const maxDuration = 300;

export async function POST(req: NextRequest) {
  const { track } = (await req.json().catch(() => ({}))) as { track?: CampaignTrack };
  const selected: CampaignTrack = track === "mentee" ? "mentee" : "mentor";
  const steps = CAMPAIGN_TRACKS[selected].steps;

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: unknown) =>
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`));

      let transcript = "";
      try {
        for (let i = 0; i < steps.length; i++) {
          const { id, brief } = steps[i];
          send({ type: "step_start", index: i, agentId: id, name: AGENTS[id].name });

          const prompt = transcript
            ? `TEAM WORK SO FAR (build on this, stay consistent):\n\n${transcript}\n\n---\nYOUR TASK: ${brief}`
            : brief;

          let text = "";
          try {
            text = await runAgent({
              system: systemFor(id),
              messages: [{ role: "user", content: prompt }],
              maxTokens: 1200,
            });
          } catch (e) {
            text = `Failed to generate: ${e instanceof Error ? e.message : "error"}`;
          }

          transcript += `\n\n### ${AGENTS[id].name}\n${text}`;
          send({ type: "step_done", index: i, agentId: id, name: AGENTS[id].name, text });
        }
        send({ type: "complete" });
      } catch (e) {
        send({ type: "error", message: e instanceof Error ? e.message : "error" });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
