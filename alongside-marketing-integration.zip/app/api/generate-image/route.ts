// app/api/generate-image/route.ts
// POST { request, size? } -> { dataUrl, prompt, provider }
// Two-stage: Claude (designer agent) turns the user's request into a strong,
// brand-aligned image prompt, then the configured image provider renders it.

import { NextRequest, NextResponse } from "next/server";
import { systemFor } from "@/lib/agents";
import { runAgent } from "@/lib/anthropic";
import { generateImage, ImageSize } from "@/lib/imagegen";

export const runtime = "nodejs";
export const maxDuration = 120;

interface Body {
  request: string;      // what the user wants ("square ad for AI Automation…")
  size?: ImageSize;
  skipPromptRewrite?: boolean; // if true, use `request` verbatim as the image prompt
}

export async function POST(req: NextRequest) {
  try {
    const { request, size = "1024x1024", skipPromptRewrite } = (await req.json()) as Body;

    if (!request || typeof request !== "string") {
      return NextResponse.json({ error: "`request` is required." }, { status: 400 });
    }

    // Stage 1 — Claude crafts a vivid, brand-aligned image prompt.
    let prompt = request;
    if (!skipPromptRewrite) {
      prompt = await runAgent({
        system: systemFor("designer"),
        messages: [{ role: "user", content: request }],
        maxTokens: 400,
      });
    }

    // Stage 2 — render the raster image.
    const image = await generateImage(prompt, size);

    return NextResponse.json({ dataUrl: image.dataUrl, prompt: image.prompt, provider: image.provider });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unexpected error.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
