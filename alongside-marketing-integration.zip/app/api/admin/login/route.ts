// app/api/admin/login/route.ts
// POST { password } -> sets a signed HttpOnly session cookie on success.

import { NextRequest, NextResponse } from "next/server";
import { SESSION_COOKIE, createSessionToken } from "@/lib/auth";
import { rateLimit, clientIp } from "@/lib/ratelimit";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  // Throttle password attempts by IP.
  const { success } = await rateLimit(`admin-login:${clientIp(req)}`);
  if (!success) return NextResponse.json({ error: "Too many attempts. Try again shortly." }, { status: 429 });

  const secret = process.env.AUTH_SECRET;
  const expected = process.env.ADMIN_PASSWORD;
  if (!secret || !expected) {
    return NextResponse.json({ error: "Auth not configured (missing AUTH_SECRET / ADMIN_PASSWORD)." }, { status: 500 });
  }

  const { password } = (await req.json().catch(() => ({}))) as { password?: string };
  if (!password || password !== expected) {
    return NextResponse.json({ error: "Incorrect password." }, { status: 401 });
  }

  const token = await createSessionToken(secret);
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 12,
  });
  return res;
}
