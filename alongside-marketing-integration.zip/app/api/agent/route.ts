// app/api/agent/route.ts
// POST { agentId, messages } -> { text }
// Runs one of the 12 BSM marketing agents as a multi-turn chat.

import { NextRequest, NextResponse } from "next/server";
import { AGENTS, AgentId, systemFor } from "@/lib/agents";
import { runAgent } from "@/lib/anthropic";

export const runtime = "nodejs";
export const maxDuration = 60;

interface Body {
  agentId: AgentId;
  messages: { role: "user" | "assistant"; content: string }[];
}

export async function POST(req: NextRequest) {
  try {
    const { agentId, messages } = (await req.json()) as Body;

    if (!agentId || !AGENTS[agentId]) {
      return NextResponse.json({ error: "Unknown agentId." }, { status: 400 });
    }
    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "messages must be a non-empty array." }, { status: 400 });
    }

    const text = await runAgent({
      system: systemFor(agentId),
      messages,
      maxTokens: 1600,
    });

    return NextResponse.json({ text });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unexpected error.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
