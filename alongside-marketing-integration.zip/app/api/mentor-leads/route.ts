// app/api/mentor-leads/route.ts
// POST   { name, email, lifeEvent, story, availability? }  -> capture + auto-qualify a mentor lead
// GET    ?status=qualified                                 -> list leads (optionally filtered) [ADMIN]
// PATCH  { id, status, score?, notes? }                    -> human override of qualification [ADMIN]
//
// Admin auth: GET/PATCH here (and /marketing/leads) are protected by middleware.ts.
// POST is the public capture endpoint and is rate-limited (see lib/ratelimit.ts).

import { NextRequest, NextResponse } from "next/server";
import { insertLead, updateQualification, listLeads, LeadStatus, NewLeadInput } from "@/lib/leads";
import { qualifyLead } from "@/lib/qualify";
import { rateLimit, clientIp } from "@/lib/ratelimit";
import { verifyTurnstile } from "@/lib/turnstile";
import { notifyHighScoringLead } from "@/lib/notify";

export const runtime = "nodejs";
export const maxDuration = 60;

const VALID_STATUS: LeadStatus[] = ["new", "qualified", "not_ready", "contacted", "converted"];

export async function POST(req: NextRequest) {
  try {
    const ip = clientIp(req);
    // Rate limit the public capture endpoint by IP.
    const { success, reset } = await rateLimit(`mentor-lead:${ip}`);
    if (!success) {
      return NextResponse.json(
        { error: "Too many submissions. Please try again shortly." },
        { status: 429, headers: { "Retry-After": String(Math.max(1, Math.ceil((reset - Date.now()) / 1000))) } }
      );
    }

    const body = (await req.json()) as NewLeadInput & { turnstileToken?: string };

    // Verify CAPTCHA before doing any work (skipped automatically if not configured).
    const human = await verifyTurnstile(body.turnstileToken, ip);
    if (!human) {
      return NextResponse.json({ error: "CAPTCHA verification failed. Please try again." }, { status: 400 });
    }

    if (!body?.name || !body?.email || !body?.lifeEvent || !body?.story) {
      return NextResponse.json({ error: "name, email, lifeEvent, and story are required." }, { status: 400 });
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(body.email)) {
      return NextResponse.json({ error: "Invalid email." }, { status: 400 });
    }

    // 1. Persist the raw lead immediately (never lose a signup).
    const lead = await insertLead(body);

    // 2. Qualify with the mentor-recruiter agent.
    const q = await qualifyLead(body);

    // 3. Store the qualification result.
    const updated = (await updateQualification(lead.id, q.score, q.status, q.notes)) ?? lead;

    // 4. Notify the team about high-scoring leads (fire-and-forget; never blocks signup).
    void notifyHighScoringLead(updated, q);

    return NextResponse.json({ lead: updated, qualification: q });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unexpected error.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const statusParam = req.nextUrl.searchParams.get("status") as LeadStatus | null;
    const status = statusParam && VALID_STATUS.includes(statusParam) ? statusParam : undefined;
    return NextResponse.json({ leads: await listLeads(status) });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unexpected error.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { id, status, score, notes } = (await req.json()) as { id: number; status: LeadStatus; score?: number; notes?: string };
    if (!id || !status || !VALID_STATUS.includes(status)) {
      return NextResponse.json({ error: "Valid id and status are required." }, { status: 400 });
    }
    const updated = await updateQualification(id, score ?? 0, status, notes ?? "");
    if (!updated) return NextResponse.json({ error: "Lead not found." }, { status: 404 });
    return NextResponse.json({ lead: updated });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unexpected error.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
