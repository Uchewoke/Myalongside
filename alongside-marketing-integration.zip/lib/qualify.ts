// lib/qualify.ts
// Uses the mentor-recruiter agent to score a prospective mentor against clear,
// compassionate criteria and return structured data. Server-only.

import { runAgent } from "./anthropic";
import { systemFor } from "./agents";
import type { LeadStatus, NewLeadInput } from "./leads";

export interface Qualification {
  score: number;          // 0-100
  status: LeadStatus;     // qualified | not_ready (auto-set from score/flags)
  notes: string;          // short human-readable rationale
  strengths: string[];
  concerns: string[];
}

const QUALIFY_SYSTEM = `${systemFor("sales")}

TASK: Assess a prospective peer MENTOR for MyAlongside. This is compassionate
screening, not gatekeeping. Judge on:
- Lived experience: have they genuinely been through the life event they'd mentor on?
- Perspective & stability: do they sound like they have enough distance/healing to support others (not still in acute crisis)?
- Empathy & communication: warmth, ability to listen.
- Availability: realistic time to commit.

SAFETY: If the person appears to still be in acute distress or crisis, they are
"not_ready" (this protects them and future mentees) — recommend they seek support
first, warmly. Never shame anyone. Lack of "credentials" is NOT disqualifying;
lived experience is the qualification.

Respond with ONLY a JSON object, no markdown, no preamble:
{
  "score": <0-100 integer>,
  "notes": "<one or two sentence rationale>",
  "strengths": ["<short>", ...],
  "concerns": ["<short>", ...],
  "acuteCrisis": <true|false>
}`;

export async function qualifyLead(input: NewLeadInput): Promise<Qualification> {
  const userMsg = `Prospective mentor:
Name: ${input.name}
Life event they'd mentor on: ${input.lifeEvent}
Their story: ${input.story}
Stated availability: ${input.availability ?? "not specified"}`;

  const raw = await runAgent({
    system: QUALIFY_SYSTEM,
    messages: [{ role: "user", content: userMsg }],
    maxTokens: 600,
  });

  let parsed: { score?: number; notes?: string; strengths?: string[]; concerns?: string[]; acuteCrisis?: boolean };
  try {
    const jsonText = raw.replace(/```json|```/g, "").trim();
    parsed = JSON.parse(jsonText);
  } catch {
    // Fallback: never hard-fail signup; flag for manual review.
    return {
      score: 50, status: "new" as LeadStatus,
      notes: "Automatic scoring unavailable — flagged for manual review.",
      strengths: [], concerns: ["Could not auto-parse qualification."],
    };
  }

  const score = Math.max(0, Math.min(100, Math.round(parsed.score ?? 0)));
  const acute = parsed.acuteCrisis === true;
  // Auto-status: acute crisis -> not_ready regardless of score; else threshold at 60.
  const status: LeadStatus = acute ? "not_ready" : score >= 60 ? "qualified" : "not_ready";

  return {
    score,
    status,
    notes: parsed.notes ?? "",
    strengths: parsed.strengths ?? [],
    concerns: parsed.concerns ?? [],
  };
}
