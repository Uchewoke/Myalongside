// lib/auth.ts
// Minimal admin auth: a signed, HttpOnly session cookie issued after the user
// presents the shared ADMIN_PASSWORD. Uses the Web Crypto API (HMAC-SHA256) so it
// runs in both the Edge middleware and Node route handlers — no external deps.
//
// Env:
//   ADMIN_PASSWORD   - the password reviewers type to sign in
//   AUTH_SECRET      - long random string used to sign the session cookie
//
// This is deliberately simple (single shared admin role). For per-user accounts,
// swap this for NextAuth/Auth.js or your existing session system — only the
// `verifySessionToken` call in middleware.ts and the login route would change.

export const SESSION_COOKIE = "myalongside_admin";
const SESSION_TTL_MS = 1000 * 60 * 60 * 12; // 12 hours

function enc(data: string): BufferSource {
  return new TextEncoder().encode(data) as unknown as BufferSource;
}

function toBase64Url(bytes: ArrayBuffer): string {
  const b = String.fromCharCode(...new Uint8Array(bytes));
  return btoa(b).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function hmac(message: string, secret: string): Promise<string> {
  const key = await crypto.subtle.importKey("raw", enc(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, enc(message));
  return toBase64Url(sig);
}

/** Create a signed session token valid for SESSION_TTL_MS. */
export async function createSessionToken(secret: string): Promise<string> {
  const payload = `admin.${Date.now() + SESSION_TTL_MS}`;
  const sig = await hmac(payload, secret);
  return `${payload}.${sig}`;
}

/** Returns true if the token is well-formed, correctly signed, and unexpired. */
export async function verifySessionToken(token: string | undefined, secret: string): Promise<boolean> {
  if (!token) return false;
  const parts = token.split(".");
  if (parts.length !== 3) return false;
  const [role, expStr, sig] = parts;
  const payload = `${role}.${expStr}`;
  const expected = await hmac(payload, secret);
  // Constant-time-ish compare.
  if (sig.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (diff !== 0) return false;
  const exp = Number(expStr);
  return Number.isFinite(exp) && exp > Date.now();
}
