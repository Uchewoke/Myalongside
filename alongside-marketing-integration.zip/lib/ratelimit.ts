// lib/ratelimit.ts
// Serverless-friendly rate limiting for public endpoints.
// Uses Upstash Redis when configured (works across Vercel's stateless functions),
// and falls back to a best-effort in-memory limiter for local dev.
//
//   npm install @upstash/ratelimit @upstash/redis
//
// Env (from the Upstash console):
//   UPSTASH_REDIS_REST_URL, UPSTASH_REDIS_REST_TOKEN
//   RATELIMIT_MAX (default 5), RATELIMIT_WINDOW (default "60 s")

import type { NextRequest } from "next/server";

export interface RateLimitResult {
  success: boolean;
  remaining: number;
  reset: number; // epoch ms when the window resets
}

const MAX = Number(process.env.RATELIMIT_MAX ?? 5);
const WINDOW = (process.env.RATELIMIT_WINDOW ?? "60 s") as `${number} s`;

// --- Upstash (production) -------------------------------------------------
type Limiter = { limit: (key: string) => Promise<{ success: boolean; remaining: number; reset: number }> };
let upstash: Limiter | null | undefined; // undefined = not yet initialized

async function getUpstash(): Promise<Limiter | null> {
  if (upstash !== undefined) return upstash;
  if (!process.env.UPSTASH_REDIS_REST_URL || !process.env.UPSTASH_REDIS_REST_TOKEN) {
    upstash = null;
    return null;
  }
  const { Ratelimit } = await import("@upstash/ratelimit");
  const { Redis } = await import("@upstash/redis");
  upstash = new Ratelimit({
    redis: Redis.fromEnv(),
    limiter: Ratelimit.slidingWindow(MAX, WINDOW),
    prefix: "myalongside:rl",
  }) as unknown as Limiter;
  return upstash;
}

// --- In-memory fallback (dev only; per-instance, not shared) --------------
const mem = new Map<string, { count: number; reset: number }>();
const WINDOW_MS = Number(WINDOW.split(" ")[0]) * 1000;

function memLimit(key: string): RateLimitResult {
  const now = Date.now();
  const entry = mem.get(key);
  if (!entry || entry.reset < now) {
    mem.set(key, { count: 1, reset: now + WINDOW_MS });
    return { success: true, remaining: MAX - 1, reset: now + WINDOW_MS };
  }
  entry.count += 1;
  const success = entry.count <= MAX;
  return { success, remaining: Math.max(0, MAX - entry.count), reset: entry.reset };
}

export async function rateLimit(key: string): Promise<RateLimitResult> {
  const limiter = await getUpstash();
  if (limiter) {
    const r = await limiter.limit(key);
    return { success: r.success, remaining: r.remaining, reset: r.reset };
  }
  return memLimit(key);
}

/** Best-effort client IP from proxy headers (Vercel sets x-forwarded-for). */
export function clientIp(req: NextRequest): string {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0].trim();
  return req.headers.get("x-real-ip") ?? "unknown";
}
