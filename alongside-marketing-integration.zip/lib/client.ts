// lib/client.ts
// Browser-side helpers that call the API routes. Safe to import in client components.

import type { AgentId, CampaignTrack } from "./agents";

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export async function askAgent(agentId: AgentId, messages: ChatMessage[]): Promise<string> {
  const res = await fetch("/api/agent", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ agentId, messages }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error ?? "Agent request failed.");
  return data.text as string;
}

export interface GeneratedAd {
  dataUrl: string;
  prompt: string;
  provider: string;
}

export async function generateAd(request: string, size?: string): Promise<GeneratedAd> {
  const res = await fetch("/api/generate-image", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ request, size }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error ?? "Image generation failed.");
  return data as GeneratedAd;
}

export interface MentorLeadResult {
  lead: { id: number; name: string; email: string; score: number; status: string; qualificationNotes: string };
  qualification: { score: number; status: string; notes: string; strengths: string[]; concerns: string[] };
}

export async function submitMentorLead(input: {
  name: string; email: string; lifeEvent: string; story: string; availability?: string; turnstileToken?: string;
}): Promise<MentorLeadResult> {
  const res = await fetch("/api/mentor-leads", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error ?? "Could not submit.");
  return data as MentorLeadResult;
}

export interface CampaignEvent {
  type: "step_start" | "step_done" | "complete" | "error";
  index?: number;
  agentId?: AgentId;
  name?: string;
  text?: string;
  message?: string;
}

/** Streams a chained campaign for the given track ("mentor" | "mentee"). */
export async function runCampaign(track: CampaignTrack, onEvent: (e: CampaignEvent) => void): Promise<void> {
  const res = await fetch("/api/campaign", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ track }),
  });
  if (!res.body) throw new Error("No response stream.");

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const parts = buffer.split("\n\n");
    buffer = parts.pop() ?? "";
    for (const part of parts) {
      const line = part.trim();
      if (!line.startsWith("data:")) continue;
      try {
        onEvent(JSON.parse(line.slice(5).trim()) as CampaignEvent);
      } catch {
        /* ignore keep-alive */
      }
    }
  }
}

export interface MentorMatch {
  mentor: { id: number; name: string; email: string; lifeEvent: string; score: number; status: string; availability: string };
  matchScore: number;
  reasons: string[];
}

export async function findMatches(event: string, limit = 5): Promise<{ event: string; matches: MentorMatch[] }> {
  const res = await fetch(`/api/match?event=${encodeURIComponent(event)}&limit=${limit}`);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error ?? "Match lookup failed.");
  return data;
}
