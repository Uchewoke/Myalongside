// lib/leads.ts
// Server-only mentor-lead store, backed by Postgres via Prisma.
// The exported interface is unchanged from the previous SQLite version, so the
// API routes and UI need no edits. Run `npx prisma migrate deploy` to create the table.
//
//   npm install @prisma/client
//   npm install -D prisma
//   npx prisma generate

import { prisma } from "./prisma";

export type LeadStatus = "new" | "qualified" | "not_ready" | "contacted" | "converted";

export interface MentorLead {
  id: number;
  name: string;
  email: string;
  lifeEvent: string;
  story: string;
  availability: string;
  score: number;
  status: LeadStatus;
  qualificationNotes: string;
  createdAt: string;   // ISO string (serialized for the client)
  updatedAt: string;
}

export interface NewLeadInput {
  name: string;
  email: string;
  lifeEvent: string;
  story: string;
  availability?: string;
}

// Prisma returns Date objects + enum; normalize to the plain shape the app expects.
function serialize(row: {
  id: number; name: string; email: string; lifeEvent: string; story: string;
  availability: string; score: number; status: string; qualificationNotes: string;
  createdAt: Date; updatedAt: Date;
}): MentorLead {
  return {
    ...row,
    status: row.status as LeadStatus,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export async function insertLead(input: NewLeadInput): Promise<MentorLead> {
  const email = input.email.trim().toLowerCase();
  const data = {
    name: input.name.trim(),
    email,
    lifeEvent: input.lifeEvent.trim(),
    story: input.story.trim(),
    availability: (input.availability ?? "").trim(),
  };
  // Upsert so a repeat signup updates rather than errors on the unique email.
  const row = await prisma.mentorLead.upsert({
    where: { email },
    update: data,
    create: data,
  });
  return serialize(row);
}

export async function updateQualification(
  id: number,
  score: number,
  status: LeadStatus,
  notes: string
): Promise<MentorLead | null> {
  try {
    const row = await prisma.mentorLead.update({
      where: { id },
      data: { score, status, qualificationNotes: notes },
    });
    return serialize(row);
  } catch {
    return null; // record not found
  }
}

export async function listLeads(status?: LeadStatus): Promise<MentorLead[]> {
  const rows = await prisma.mentorLead.findMany({
    where: status ? { status } : undefined,
    orderBy: status ? [{ score: "desc" }, { createdAt: "desc" }] : [{ createdAt: "desc" }],
  });
  return rows.map(serialize);
}

export async function getLead(id: number): Promise<MentorLead | null> {
  const row = await prisma.mentorLead.findUnique({ where: { id } });
  return row ? serialize(row) : null;
}
