// middleware.ts  (project root)
// Protects admin surfaces: the leads dashboard page and the GET/PATCH lead APIs.
// The public POST /api/mentor-leads capture endpoint stays open (it's rate-limited).
// Unauthenticated dashboard visits redirect to /marketing/login; unauthenticated
// admin API calls get 401.

import { NextRequest, NextResponse } from "next/server";
import { SESSION_COOKIE, verifySessionToken } from "@/lib/auth";

export const config = {
  matcher: ["/marketing/leads/:path*", "/marketing/match/:path*", "/api/mentor-leads", "/api/match"],
};

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Public capture: allow POST through untouched (rate-limited in the route).
  if (pathname === "/api/mentor-leads" && req.method === "POST") {
    return NextResponse.next();
  }

  const secret = process.env.AUTH_SECRET ?? "";
  const authed = secret ? await verifySessionToken(req.cookies.get(SESSION_COOKIE)?.value, secret) : false;
  if (authed) return NextResponse.next();

  // API (GET/PATCH) -> 401 JSON. Pages -> redirect to login.
  if (pathname.startsWith("/api/")) {
    return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  }
  const url = req.nextUrl.clone();
  url.pathname = "/marketing/login";
  url.searchParams.set("next", pathname);
  return NextResponse.redirect(url);
}
